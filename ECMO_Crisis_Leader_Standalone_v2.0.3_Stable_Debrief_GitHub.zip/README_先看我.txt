ECMO Crisis Leader v2.0.3 — Stable Debrief
Root-cause repair:
- Debrief no longer depends on chained window.debrief wrappers.
- One self-contained ECL_OPEN_DEBRIEF renderer lives inside the app scope and has direct access to case state.
- Both top Debrief and floating bottom Debrief call the same renderer.
- Explicitly opens modal with class + display:flex + highest z-index.
- Existing v2 physiology engine and v2.0.2 monitor fidelity preserved.
